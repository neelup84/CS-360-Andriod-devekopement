package com.example.greetings;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView textView = findViewById(R.id.TextView8);

        // receiving the data from the first activity
        Bundle extras = getIntent().getExtras();
        if (extras == null){
            return;
        }
        String msg = extras.getString("myName");
        textView.setText("Hello "+msg + ", I hope you are doing well!");
        }

    }
